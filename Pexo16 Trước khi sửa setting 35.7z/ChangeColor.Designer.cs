﻿namespace Pexo16
{
    partial class ChangeColor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param Name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.lbl_Ch1 = new System.Windows.Forms.Label();
            this.lbl_Ch2 = new System.Windows.Forms.Label();
            this.lbl_Ch3 = new System.Windows.Forms.Label();
            this.lbl_Ch4 = new System.Windows.Forms.Label();
            this.lbl_Ch5 = new System.Windows.Forms.Label();
            this.lbl_Ch6 = new System.Windows.Forms.Label();
            this.lbl_Ch7 = new System.Windows.Forms.Label();
            this.lbl_Ch8 = new System.Windows.Forms.Label();
            this.btnCh1 = new System.Windows.Forms.Button();
            this.btnCh2 = new System.Windows.Forms.Button();
            this.btnCh3 = new System.Windows.Forms.Button();
            this.btnCh4 = new System.Windows.Forms.Button();
            this.btnCh5 = new System.Windows.Forms.Button();
            this.btnCh6 = new System.Windows.Forms.Button();
            this.btnCh7 = new System.Windows.Forms.Button();
            this.btnCh8 = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.colorDialog2 = new System.Windows.Forms.ColorDialog();
            this.colorDialog3 = new System.Windows.Forms.ColorDialog();
            this.colorDialog4 = new System.Windows.Forms.ColorDialog();
            this.colorDialog5 = new System.Windows.Forms.ColorDialog();
            this.colorDialog6 = new System.Windows.Forms.ColorDialog();
            this.colorDialog7 = new System.Windows.Forms.ColorDialog();
            this.colorDialog8 = new System.Windows.Forms.ColorDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_Ch1
            // 
            this.lbl_Ch1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ch1.Location = new System.Drawing.Point(173, 16);
            this.lbl_Ch1.Name = "lbl_Ch1";
            this.lbl_Ch1.Size = new System.Drawing.Size(80, 15);
            this.lbl_Ch1.TabIndex = 0;
            // 
            // lbl_Ch2
            // 
            this.lbl_Ch2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ch2.Location = new System.Drawing.Point(173, 53);
            this.lbl_Ch2.Name = "lbl_Ch2";
            this.lbl_Ch2.Size = new System.Drawing.Size(80, 15);
            this.lbl_Ch2.TabIndex = 0;
            // 
            // lbl_Ch3
            // 
            this.lbl_Ch3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ch3.Location = new System.Drawing.Point(173, 98);
            this.lbl_Ch3.Name = "lbl_Ch3";
            this.lbl_Ch3.Size = new System.Drawing.Size(80, 15);
            this.lbl_Ch3.TabIndex = 0;
            // 
            // lbl_Ch4
            // 
            this.lbl_Ch4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ch4.Location = new System.Drawing.Point(173, 137);
            this.lbl_Ch4.Name = "lbl_Ch4";
            this.lbl_Ch4.Size = new System.Drawing.Size(80, 15);
            this.lbl_Ch4.TabIndex = 0;
            // 
            // lbl_Ch5
            // 
            this.lbl_Ch5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ch5.Location = new System.Drawing.Point(173, 179);
            this.lbl_Ch5.Name = "lbl_Ch5";
            this.lbl_Ch5.Size = new System.Drawing.Size(80, 15);
            this.lbl_Ch5.TabIndex = 0;
            // 
            // lbl_Ch6
            // 
            this.lbl_Ch6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ch6.Location = new System.Drawing.Point(173, 223);
            this.lbl_Ch6.Name = "lbl_Ch6";
            this.lbl_Ch6.Size = new System.Drawing.Size(80, 15);
            this.lbl_Ch6.TabIndex = 0;
            // 
            // lbl_Ch7
            // 
            this.lbl_Ch7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ch7.Location = new System.Drawing.Point(173, 267);
            this.lbl_Ch7.Name = "lbl_Ch7";
            this.lbl_Ch7.Size = new System.Drawing.Size(80, 15);
            this.lbl_Ch7.TabIndex = 0;
            // 
            // lbl_Ch8
            // 
            this.lbl_Ch8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ch8.Location = new System.Drawing.Point(173, 308);
            this.lbl_Ch8.Name = "lbl_Ch8";
            this.lbl_Ch8.Size = new System.Drawing.Size(80, 15);
            this.lbl_Ch8.TabIndex = 0;
            // 
            // btnCh1
            // 
            this.btnCh1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCh1.Location = new System.Drawing.Point(319, 12);
            this.btnCh1.Name = "btnCh1";
            this.btnCh1.Size = new System.Drawing.Size(75, 23);
            this.btnCh1.TabIndex = 1;
            this.btnCh1.Text = "Change";
            this.btnCh1.UseVisualStyleBackColor = true;
            this.btnCh1.Click += new System.EventHandler(this.btnCh1_Click);
            // 
            // btnCh2
            // 
            this.btnCh2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCh2.Location = new System.Drawing.Point(319, 49);
            this.btnCh2.Name = "btnCh2";
            this.btnCh2.Size = new System.Drawing.Size(75, 23);
            this.btnCh2.TabIndex = 1;
            this.btnCh2.Text = "Change";
            this.btnCh2.UseVisualStyleBackColor = true;
            this.btnCh2.Click += new System.EventHandler(this.btnCh2_Click);
            // 
            // btnCh3
            // 
            this.btnCh3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCh3.Location = new System.Drawing.Point(319, 94);
            this.btnCh3.Name = "btnCh3";
            this.btnCh3.Size = new System.Drawing.Size(75, 23);
            this.btnCh3.TabIndex = 1;
            this.btnCh3.Text = "Change";
            this.btnCh3.UseVisualStyleBackColor = true;
            this.btnCh3.Click += new System.EventHandler(this.btnCh3_Click);
            // 
            // btnCh4
            // 
            this.btnCh4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCh4.Location = new System.Drawing.Point(319, 133);
            this.btnCh4.Name = "btnCh4";
            this.btnCh4.Size = new System.Drawing.Size(75, 23);
            this.btnCh4.TabIndex = 1;
            this.btnCh4.Text = "Change";
            this.btnCh4.UseVisualStyleBackColor = true;
            this.btnCh4.Click += new System.EventHandler(this.btnCh4_Click);
            // 
            // btnCh5
            // 
            this.btnCh5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCh5.Location = new System.Drawing.Point(319, 175);
            this.btnCh5.Name = "btnCh5";
            this.btnCh5.Size = new System.Drawing.Size(75, 23);
            this.btnCh5.TabIndex = 1;
            this.btnCh5.Text = "Change";
            this.btnCh5.UseVisualStyleBackColor = true;
            this.btnCh5.Click += new System.EventHandler(this.btnCh5_Click);
            // 
            // btnCh6
            // 
            this.btnCh6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCh6.Location = new System.Drawing.Point(319, 219);
            this.btnCh6.Name = "btnCh6";
            this.btnCh6.Size = new System.Drawing.Size(75, 23);
            this.btnCh6.TabIndex = 1;
            this.btnCh6.Text = "Change";
            this.btnCh6.UseVisualStyleBackColor = true;
            this.btnCh6.Click += new System.EventHandler(this.btnCh6_Click);
            // 
            // btnCh7
            // 
            this.btnCh7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCh7.Location = new System.Drawing.Point(319, 263);
            this.btnCh7.Name = "btnCh7";
            this.btnCh7.Size = new System.Drawing.Size(75, 23);
            this.btnCh7.TabIndex = 1;
            this.btnCh7.Text = "Change";
            this.btnCh7.UseVisualStyleBackColor = true;
            this.btnCh7.Click += new System.EventHandler(this.btnCh7_Click);
            // 
            // btnCh8
            // 
            this.btnCh8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCh8.Location = new System.Drawing.Point(319, 304);
            this.btnCh8.Name = "btnCh8";
            this.btnCh8.Size = new System.Drawing.Size(75, 23);
            this.btnCh8.TabIndex = 1;
            this.btnCh8.Text = "Change";
            this.btnCh8.UseVisualStyleBackColor = true;
            this.btnCh8.Click += new System.EventHandler(this.btnCh8_Click);
            // 
            // btnOK
            // 
            this.btnOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOK.Location = new System.Drawing.Point(75, 362);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(87, 31);
            this.btnOK.TabIndex = 1;
            this.btnOK.Text = "Ok";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(269, 362);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(88, 31);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(36, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "Channel 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(36, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Channel 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(36, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Channel 3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(36, 137);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 15);
            this.label4.TabIndex = 2;
            this.label4.Text = "Channel 4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(36, 179);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 15);
            this.label5.TabIndex = 2;
            this.label5.Text = "Channel 5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(36, 223);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 15);
            this.label6.TabIndex = 2;
            this.label6.Text = "Channel 6";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(36, 267);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 15);
            this.label7.TabIndex = 2;
            this.label7.Text = "Channel 7";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(36, 308);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 15);
            this.label8.TabIndex = 2;
            this.label8.Text = "Channel 8";
            // 
            // ChangeColor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 405);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btnCh8);
            this.Controls.Add(this.btnCh7);
            this.Controls.Add(this.btnCh6);
            this.Controls.Add(this.btnCh5);
            this.Controls.Add(this.btnCh4);
            this.Controls.Add(this.btnCh3);
            this.Controls.Add(this.btnCh2);
            this.Controls.Add(this.btnCh1);
            this.Controls.Add(this.lbl_Ch8);
            this.Controls.Add(this.lbl_Ch7);
            this.Controls.Add(this.lbl_Ch6);
            this.Controls.Add(this.lbl_Ch5);
            this.Controls.Add(this.lbl_Ch4);
            this.Controls.Add(this.lbl_Ch3);
            this.Controls.Add(this.lbl_Ch2);
            this.Controls.Add(this.lbl_Ch1);
            this.Name = "ChangeColor";
            this.Text = "Change Color";
            this.Load += new System.EventHandler(this.frmChangeColor_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Label lbl_Ch1;
        private System.Windows.Forms.Label lbl_Ch2;
        private System.Windows.Forms.Label lbl_Ch3;
        private System.Windows.Forms.Label lbl_Ch4;
        private System.Windows.Forms.Label lbl_Ch5;
        private System.Windows.Forms.Label lbl_Ch6;
        private System.Windows.Forms.Label lbl_Ch7;
        private System.Windows.Forms.Label lbl_Ch8;
        private System.Windows.Forms.Button btnCh2;
        private System.Windows.Forms.Button btnCh3;
        private System.Windows.Forms.Button btnCh4;
        private System.Windows.Forms.Button btnCh5;
        private System.Windows.Forms.Button btnCh6;
        private System.Windows.Forms.Button btnCh7;
        private System.Windows.Forms.Button btnCh8;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.ColorDialog colorDialog2;
        private System.Windows.Forms.ColorDialog colorDialog3;
        private System.Windows.Forms.ColorDialog colorDialog4;
        private System.Windows.Forms.ColorDialog colorDialog5;
        private System.Windows.Forms.ColorDialog colorDialog6;
        private System.Windows.Forms.ColorDialog colorDialog7;
        private System.Windows.Forms.ColorDialog colorDialog8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        public System.Windows.Forms.Button btnCh1;
    }
}