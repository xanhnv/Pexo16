﻿namespace Pexo16
{
    partial class Calibrations
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbCalHum1 = new System.Windows.Forms.GroupBox();
            this.grbCalTemp1 = new System.Windows.Forms.GroupBox();
            this.label105 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.cbbNumCalPoint1 = new System.Windows.Forms.ComboBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtRefHum4Prob1 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtRefHum3Prob1 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtRefHum2Prob1 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.txtRefHum1Prob1 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.btnCalProb1 = new System.Windows.Forms.Button();
            this.grbCalHum2 = new System.Windows.Forms.GroupBox();
            this.grbCalTemp2 = new System.Windows.Forms.GroupBox();
            this.label86 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.cbbNumCalPoint2 = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtRefHum4Prob2 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.txtRefHum3Prob2 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.txtRefHum2Prob2 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.label39 = new System.Windows.Forms.Label();
            this.txtRefHum1Prob2 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.grbCalHum3 = new System.Windows.Forms.GroupBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.cbbNumCalPoint3 = new System.Windows.Forms.ComboBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.txtRefHum4Prob3 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.txtRefHum3Prob3 = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.txtRefHum2Prob3 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.label60 = new System.Windows.Forms.Label();
            this.txtRefHum1Prob3 = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.grbCalTemp3 = new System.Windows.Forms.GroupBox();
            this.label87 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.grbCalHum4 = new System.Windows.Forms.GroupBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.cbbNumCalPoint4 = new System.Windows.Forms.ComboBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.radioButton16 = new System.Windows.Forms.RadioButton();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.txtRefHum4Prob4 = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.radioButton15 = new System.Windows.Forms.RadioButton();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.txtRefHum3Prob4 = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.radioButton14 = new System.Windows.Forms.RadioButton();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.txtRefHum2Prob4 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.radioButton13 = new System.Windows.Forms.RadioButton();
            this.label81 = new System.Windows.Forms.Label();
            this.txtRefHum1Prob4 = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.label84 = new System.Windows.Forms.Label();
            this.grbCalTemp4 = new System.Windows.Forms.GroupBox();
            this.label85 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.btnReadProb3 = new System.Windows.Forms.Button();
            this.btnCalProb2 = new System.Windows.Forms.Button();
            this.btnCalProb3 = new System.Windows.Forms.Button();
            this.btnCalProb4 = new System.Windows.Forms.Button();
            this.btnReadProb1 = new System.Windows.Forms.Button();
            this.btnReadProb2 = new System.Windows.Forms.Button();
            this.btnReadProb4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.grbCalHum1.SuspendLayout();
            this.grbCalTemp1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.grbCalHum2.SuspendLayout();
            this.grbCalTemp2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.grbCalHum3.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.grbCalTemp3.SuspendLayout();
            this.grbCalHum4.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel16.SuspendLayout();
            this.grbCalTemp4.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbCalHum1
            // 
            this.grbCalHum1.Controls.Add(this.label2);
            this.grbCalHum1.Controls.Add(this.label31);
            this.grbCalHum1.Controls.Add(this.label32);
            this.grbCalHum1.Controls.Add(this.label30);
            this.grbCalHum1.Controls.Add(this.cbbNumCalPoint1);
            this.grbCalHum1.Controls.Add(this.panel5);
            this.grbCalHum1.Controls.Add(this.panel6);
            this.grbCalHum1.Controls.Add(this.panel7);
            this.grbCalHum1.Controls.Add(this.panel8);
            this.grbCalHum1.Controls.Add(this.grbCalTemp1);
            this.grbCalHum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbCalHum1.Location = new System.Drawing.Point(4, 1);
            this.grbCalHum1.Name = "grbCalHum1";
            this.grbCalHum1.Size = new System.Drawing.Size(431, 195);
            this.grbCalHum1.TabIndex = 20;
            this.grbCalHum1.TabStop = false;
            this.grbCalHum1.Text = "Probe 1: Calib Humid";
            // 
            // grbCalTemp1
            // 
            this.grbCalTemp1.Controls.Add(this.label105);
            this.grbCalTemp1.Controls.Add(this.label88);
            this.grbCalTemp1.Controls.Add(this.textBox51);
            this.grbCalTemp1.Location = new System.Drawing.Point(0, 0);
            this.grbCalTemp1.Name = "grbCalTemp1";
            this.grbCalTemp1.Size = new System.Drawing.Size(431, 195);
            this.grbCalTemp1.TabIndex = 26;
            this.grbCalTemp1.TabStop = false;
            this.grbCalTemp1.Text = "Probe 1: Calib Temp";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label105.Location = new System.Drawing.Point(325, 99);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(35, 13);
            this.label105.TabIndex = 35;
            this.label105.Text = "x10°C";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.Location = new System.Drawing.Point(62, 97);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(70, 13);
            this.label88.TabIndex = 31;
            this.label88.Text = "Data offset";
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(183, 92);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(136, 20);
            this.textBox51.TabIndex = 30;
            this.textBox51.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox51.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            this.textBox51.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox51_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(180, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 25;
            this.label2.Text = "Current rH";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(300, 46);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(83, 13);
            this.label31.TabIndex = 24;
            this.label31.Text = "Reference rH";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(59, 46);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(90, 13);
            this.label32.TabIndex = 23;
            this.label32.Text = "Temperature T";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(7, 21);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(121, 13);
            this.label30.TabIndex = 22;
            this.label30.Text = "Number calibration point";
            // 
            // cbbNumCalPoint1
            // 
            this.cbbNumCalPoint1.FormattingEnabled = true;
            this.cbbNumCalPoint1.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4"});
            this.cbbNumCalPoint1.Location = new System.Drawing.Point(134, 18);
            this.cbbNumCalPoint1.Name = "cbbNumCalPoint1";
            this.cbbNumCalPoint1.Size = new System.Drawing.Size(89, 21);
            this.cbbNumCalPoint1.TabIndex = 21;
            this.cbbNumCalPoint1.SelectedIndexChanged += new System.EventHandler(this.cbbNumofCalPoint_SelectedIndexChanged);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.radioButton4);
            this.panel5.Controls.Add(this.label8);
            this.panel5.Controls.Add(this.label5);
            this.panel5.Controls.Add(this.label16);
            this.panel5.Controls.Add(this.txtRefHum4Prob1);
            this.panel5.Controls.Add(this.label17);
            this.panel5.Controls.Add(this.textBox1);
            this.panel5.Controls.Add(this.textBox2);
            this.panel5.Controls.Add(this.label18);
            this.panel5.Location = new System.Drawing.Point(6, 152);
            this.panel5.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(424, 27);
            this.panel5.TabIndex = 16;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(405, 7);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(14, 13);
            this.radioButton4.TabIndex = 12;
            this.radioButton4.TabStop = true;
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(144, 6);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(18, 13);
            this.label8.TabIndex = 22;
            this.label8.Text = "°C";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(385, 4);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(15, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "%";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(265, 6);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(15, 13);
            this.label16.TabIndex = 9;
            this.label16.Text = "%";
            // 
            // txtRefHum4Prob1
            // 
            this.txtRefHum4Prob1.Location = new System.Drawing.Point(297, 4);
            this.txtRefHum4Prob1.Name = "txtRefHum4Prob1";
            this.txtRefHum4Prob1.Size = new System.Drawing.Size(82, 20);
            this.txtRefHum4Prob1.TabIndex = 14;
            this.txtRefHum4Prob1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRefHum4Prob1_KeyPress);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(156, 6);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(0, 13);
            this.label17.TabIndex = 8;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(177, 3);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(82, 20);
            this.textBox1.TabIndex = 7;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(56, 3);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(82, 20);
            this.textBox2.TabIndex = 5;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            this.textBox2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox2_KeyPress);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(3, 10);
            this.label18.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(47, 13);
            this.label18.TabIndex = 4;
            this.label18.Text = "Point 4";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.radioButton3);
            this.panel6.Controls.Add(this.label7);
            this.panel6.Controls.Add(this.label4);
            this.panel6.Controls.Add(this.txtRefHum3Prob1);
            this.panel6.Controls.Add(this.label19);
            this.panel6.Controls.Add(this.textBox3);
            this.panel6.Controls.Add(this.textBox4);
            this.panel6.Controls.Add(this.label21);
            this.panel6.Location = new System.Drawing.Point(6, 122);
            this.panel6.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(424, 27);
            this.panel6.TabIndex = 17;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(406, 6);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(14, 13);
            this.radioButton3.TabIndex = 12;
            this.radioButton3.TabStop = true;
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(144, 6);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(18, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "°C";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(385, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(15, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "%";
            // 
            // txtRefHum3Prob1
            // 
            this.txtRefHum3Prob1.Location = new System.Drawing.Point(297, 3);
            this.txtRefHum3Prob1.Name = "txtRefHum3Prob1";
            this.txtRefHum3Prob1.Size = new System.Drawing.Size(82, 20);
            this.txtRefHum3Prob1.TabIndex = 12;
            this.txtRefHum3Prob1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRefHum3Prob1_KeyPress);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(265, 6);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(15, 13);
            this.label19.TabIndex = 9;
            this.label19.Text = "%";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(177, 3);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(82, 20);
            this.textBox3.TabIndex = 7;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            this.textBox3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox3_KeyPress);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(56, 3);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(82, 20);
            this.textBox4.TabIndex = 5;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            this.textBox4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox4_KeyPress);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(3, 10);
            this.label21.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(47, 13);
            this.label21.TabIndex = 4;
            this.label21.Text = "Point 3";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.radioButton2);
            this.panel7.Controls.Add(this.label6);
            this.panel7.Controls.Add(this.label3);
            this.panel7.Controls.Add(this.label22);
            this.panel7.Controls.Add(this.txtRefHum2Prob1);
            this.panel7.Controls.Add(this.textBox5);
            this.panel7.Controls.Add(this.textBox6);
            this.panel7.Controls.Add(this.label24);
            this.panel7.Location = new System.Drawing.Point(6, 92);
            this.panel7.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(424, 27);
            this.panel7.TabIndex = 15;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Checked = true;
            this.radioButton2.Location = new System.Drawing.Point(405, 6);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(14, 13);
            this.radioButton2.TabIndex = 12;
            this.radioButton2.TabStop = true;
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(144, 6);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(18, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "°C";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(385, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(15, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "%";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(265, 6);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(15, 13);
            this.label22.TabIndex = 9;
            this.label22.Text = "%";
            // 
            // txtRefHum2Prob1
            // 
            this.txtRefHum2Prob1.Location = new System.Drawing.Point(297, 6);
            this.txtRefHum2Prob1.Name = "txtRefHum2Prob1";
            this.txtRefHum2Prob1.Size = new System.Drawing.Size(82, 20);
            this.txtRefHum2Prob1.TabIndex = 12;
            this.txtRefHum2Prob1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRefHum2Prob1_KeyPress);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(177, 3);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(82, 20);
            this.textBox5.TabIndex = 7;
            this.textBox5.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            this.textBox5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(56, 3);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(82, 20);
            this.textBox6.TabIndex = 5;
            this.textBox6.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            this.textBox6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox6_KeyPress);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(3, 10);
            this.label24.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(47, 13);
            this.label24.TabIndex = 4;
            this.label24.Text = "Point 2";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.radioButton1);
            this.panel8.Controls.Add(this.label1);
            this.panel8.Controls.Add(this.txtRefHum1Prob1);
            this.panel8.Controls.Add(this.label27);
            this.panel8.Controls.Add(this.label28);
            this.panel8.Controls.Add(this.textBox7);
            this.panel8.Controls.Add(this.textBox8);
            this.panel8.Controls.Add(this.label29);
            this.panel8.Location = new System.Drawing.Point(6, 62);
            this.panel8.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(424, 27);
            this.panel8.TabIndex = 12;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(405, 6);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(14, 13);
            this.radioButton1.TabIndex = 12;
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(385, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(15, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "%";
            // 
            // txtRefHum1Prob1
            // 
            this.txtRefHum1Prob1.Location = new System.Drawing.Point(297, 3);
            this.txtRefHum1Prob1.Name = "txtRefHum1Prob1";
            this.txtRefHum1Prob1.Size = new System.Drawing.Size(82, 20);
            this.txtRefHum1Prob1.TabIndex = 10;
            this.txtRefHum1Prob1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRefHum1Prob1_KeyPress);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(265, 6);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(15, 13);
            this.label27.TabIndex = 9;
            this.label27.Text = "%";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(144, 6);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(18, 13);
            this.label28.TabIndex = 8;
            this.label28.Text = "°C";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(177, 3);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(82, 20);
            this.textBox7.TabIndex = 7;
            this.textBox7.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            this.textBox7.Enter += new System.EventHandler(this.txActT1_Enter);
            this.textBox7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox7_KeyPress);
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(56, 4);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(82, 20);
            this.textBox8.TabIndex = 5;
            this.textBox8.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            this.textBox8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox8_KeyPress);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(3, 10);
            this.label29.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(47, 13);
            this.label29.TabIndex = 4;
            this.label29.Text = "Point 1";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnCalProb1
            // 
            this.btnCalProb1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalProb1.Location = new System.Drawing.Point(234, 202);
            this.btnCalProb1.Name = "btnCalProb1";
            this.btnCalProb1.Size = new System.Drawing.Size(68, 38);
            this.btnCalProb1.TabIndex = 21;
            this.btnCalProb1.Text = "Calibrate";
            this.btnCalProb1.UseVisualStyleBackColor = true;
            this.btnCalProb1.Click += new System.EventHandler(this.button1_Click);
            // 
            // grbCalHum2
            // 
            this.grbCalHum2.Controls.Add(this.label9);
            this.grbCalHum2.Controls.Add(this.label10);
            this.grbCalHum2.Controls.Add(this.label11);
            this.grbCalHum2.Controls.Add(this.label12);
            this.grbCalHum2.Controls.Add(this.cbbNumCalPoint2);
            this.grbCalHum2.Controls.Add(this.panel1);
            this.grbCalHum2.Controls.Add(this.panel2);
            this.grbCalHum2.Controls.Add(this.panel3);
            this.grbCalHum2.Controls.Add(this.panel4);
            this.grbCalHum2.Controls.Add(this.grbCalTemp2);
            this.grbCalHum2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbCalHum2.Location = new System.Drawing.Point(454, 1);
            this.grbCalHum2.Name = "grbCalHum2";
            this.grbCalHum2.Size = new System.Drawing.Size(430, 195);
            this.grbCalHum2.TabIndex = 26;
            this.grbCalHum2.TabStop = false;
            this.grbCalHum2.Text = "Probe 2: Calib Humid";
            // 
            // grbCalTemp2
            // 
            this.grbCalTemp2.Controls.Add(this.label86);
            this.grbCalTemp2.Controls.Add(this.label89);
            this.grbCalTemp2.Controls.Add(this.textBox52);
            this.grbCalTemp2.Location = new System.Drawing.Point(0, 0);
            this.grbCalTemp2.Name = "grbCalTemp2";
            this.grbCalTemp2.Size = new System.Drawing.Size(430, 195);
            this.grbCalTemp2.TabIndex = 27;
            this.grbCalTemp2.TabStop = false;
            this.grbCalTemp2.Text = "Probe 2: Calib Temp";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.Location = new System.Drawing.Point(335, 99);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(35, 13);
            this.label86.TabIndex = 35;
            this.label86.Text = "x10°C";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.Location = new System.Drawing.Point(72, 100);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(70, 13);
            this.label89.TabIndex = 31;
            this.label89.Text = "Data offset";
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(193, 95);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(136, 20);
            this.textBox52.TabIndex = 30;
            this.textBox52.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox52.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            this.textBox52.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox51_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(180, 46);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 13);
            this.label9.TabIndex = 25;
            this.label9.Text = "Current rH";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(300, 46);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(83, 13);
            this.label10.TabIndex = 24;
            this.label10.Text = "Reference rH";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(59, 46);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(90, 13);
            this.label11.TabIndex = 23;
            this.label11.Text = "Temperature T";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(7, 21);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(121, 13);
            this.label12.TabIndex = 22;
            this.label12.Text = "Number calibration point";
            // 
            // cbbNumCalPoint2
            // 
            this.cbbNumCalPoint2.FormattingEnabled = true;
            this.cbbNumCalPoint2.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4"});
            this.cbbNumCalPoint2.Location = new System.Drawing.Point(134, 18);
            this.cbbNumCalPoint2.Name = "cbbNumCalPoint2";
            this.cbbNumCalPoint2.Size = new System.Drawing.Size(89, 21);
            this.cbbNumCalPoint2.Sorted = true;
            this.cbbNumCalPoint2.TabIndex = 21;
            this.cbbNumCalPoint2.SelectedIndexChanged += new System.EventHandler(this.cbbNumCalPoint2_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radioButton12);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.txtRefHum4Prob2);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.textBox14);
            this.panel1.Controls.Add(this.textBox15);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Location = new System.Drawing.Point(6, 152);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(424, 27);
            this.panel1.TabIndex = 16;
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Location = new System.Drawing.Point(406, 7);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(14, 13);
            this.radioButton12.TabIndex = 13;
            this.radioButton12.UseVisualStyleBackColor = true;
            this.radioButton12.CheckedChanged += new System.EventHandler(this.radioButton9_CheckedChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(144, 6);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(18, 13);
            this.label13.TabIndex = 22;
            this.label13.Text = "°C";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(385, 4);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(15, 13);
            this.label14.TabIndex = 15;
            this.label14.Text = "%";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(265, 6);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(15, 13);
            this.label15.TabIndex = 9;
            this.label15.Text = "%";
            // 
            // txtRefHum4Prob2
            // 
            this.txtRefHum4Prob2.Location = new System.Drawing.Point(297, 4);
            this.txtRefHum4Prob2.Name = "txtRefHum4Prob2";
            this.txtRefHum4Prob2.Size = new System.Drawing.Size(82, 20);
            this.txtRefHum4Prob2.TabIndex = 14;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(156, 6);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(0, 13);
            this.label20.TabIndex = 8;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(177, 3);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(82, 20);
            this.textBox14.TabIndex = 7;
            this.textBox14.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(56, 3);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(82, 20);
            this.textBox15.TabIndex = 5;
            this.textBox15.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(3, 10);
            this.label23.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(47, 13);
            this.label23.TabIndex = 4;
            this.label23.Text = "Point 4";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.radioButton11);
            this.panel2.Controls.Add(this.label25);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.txtRefHum3Prob2);
            this.panel2.Controls.Add(this.label33);
            this.panel2.Controls.Add(this.textBox17);
            this.panel2.Controls.Add(this.textBox18);
            this.panel2.Controls.Add(this.label34);
            this.panel2.Location = new System.Drawing.Point(6, 122);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(424, 27);
            this.panel2.TabIndex = 17;
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Location = new System.Drawing.Point(404, 6);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(14, 13);
            this.radioButton11.TabIndex = 13;
            this.radioButton11.UseVisualStyleBackColor = true;
            this.radioButton11.CheckedChanged += new System.EventHandler(this.radioButton9_CheckedChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(144, 6);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(18, 13);
            this.label25.TabIndex = 15;
            this.label25.Text = "°C";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(385, 3);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(15, 13);
            this.label26.TabIndex = 13;
            this.label26.Text = "%";
            // 
            // txtRefHum3Prob2
            // 
            this.txtRefHum3Prob2.Location = new System.Drawing.Point(297, 3);
            this.txtRefHum3Prob2.Name = "txtRefHum3Prob2";
            this.txtRefHum3Prob2.Size = new System.Drawing.Size(82, 20);
            this.txtRefHum3Prob2.TabIndex = 12;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(265, 6);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(15, 13);
            this.label33.TabIndex = 9;
            this.label33.Text = "%";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(177, 3);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(82, 20);
            this.textBox17.TabIndex = 7;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(56, 3);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(82, 20);
            this.textBox18.TabIndex = 5;
            this.textBox18.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(3, 10);
            this.label34.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(47, 13);
            this.label34.TabIndex = 4;
            this.label34.Text = "Point 3";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.radioButton10);
            this.panel3.Controls.Add(this.label35);
            this.panel3.Controls.Add(this.label36);
            this.panel3.Controls.Add(this.label37);
            this.panel3.Controls.Add(this.txtRefHum2Prob2);
            this.panel3.Controls.Add(this.textBox20);
            this.panel3.Controls.Add(this.textBox21);
            this.panel3.Controls.Add(this.label38);
            this.panel3.Location = new System.Drawing.Point(6, 92);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(424, 27);
            this.panel3.TabIndex = 15;
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Checked = true;
            this.radioButton10.Location = new System.Drawing.Point(404, 9);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(14, 13);
            this.radioButton10.TabIndex = 13;
            this.radioButton10.TabStop = true;
            this.radioButton10.UseVisualStyleBackColor = true;
            this.radioButton10.CheckedChanged += new System.EventHandler(this.radioButton9_CheckedChanged);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(144, 6);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(18, 13);
            this.label35.TabIndex = 14;
            this.label35.Text = "°C";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(385, 6);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(15, 13);
            this.label36.TabIndex = 13;
            this.label36.Text = "%";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(265, 6);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(15, 13);
            this.label37.TabIndex = 9;
            this.label37.Text = "%";
            // 
            // txtRefHum2Prob2
            // 
            this.txtRefHum2Prob2.Location = new System.Drawing.Point(297, 6);
            this.txtRefHum2Prob2.Name = "txtRefHum2Prob2";
            this.txtRefHum2Prob2.Size = new System.Drawing.Size(82, 20);
            this.txtRefHum2Prob2.TabIndex = 12;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(177, 3);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(82, 20);
            this.textBox20.TabIndex = 7;
            this.textBox20.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(56, 3);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(82, 20);
            this.textBox21.TabIndex = 5;
            this.textBox21.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(3, 10);
            this.label38.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(47, 13);
            this.label38.TabIndex = 4;
            this.label38.Text = "Point 2";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.radioButton9);
            this.panel4.Controls.Add(this.label39);
            this.panel4.Controls.Add(this.txtRefHum1Prob2);
            this.panel4.Controls.Add(this.label40);
            this.panel4.Controls.Add(this.label41);
            this.panel4.Controls.Add(this.textBox23);
            this.panel4.Controls.Add(this.textBox24);
            this.panel4.Controls.Add(this.label42);
            this.panel4.Location = new System.Drawing.Point(6, 62);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(424, 27);
            this.panel4.TabIndex = 12;
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(404, 6);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(14, 13);
            this.radioButton9.TabIndex = 13;
            this.radioButton9.UseVisualStyleBackColor = true;
            this.radioButton9.CheckedChanged += new System.EventHandler(this.radioButton9_CheckedChanged);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(385, 6);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(15, 13);
            this.label39.TabIndex = 11;
            this.label39.Text = "%";
            // 
            // txtRefHum1Prob2
            // 
            this.txtRefHum1Prob2.Location = new System.Drawing.Point(297, 3);
            this.txtRefHum1Prob2.Name = "txtRefHum1Prob2";
            this.txtRefHum1Prob2.Size = new System.Drawing.Size(82, 20);
            this.txtRefHum1Prob2.TabIndex = 10;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(265, 6);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(15, 13);
            this.label40.TabIndex = 9;
            this.label40.Text = "%";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(144, 6);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(18, 13);
            this.label41.TabIndex = 8;
            this.label41.Text = "°C";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(177, 3);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(82, 20);
            this.textBox23.TabIndex = 7;
            this.textBox23.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(56, 4);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(82, 20);
            this.textBox24.TabIndex = 5;
            this.textBox24.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(3, 10);
            this.label42.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(47, 13);
            this.label42.TabIndex = 4;
            this.label42.Text = "Point 1";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grbCalHum3
            // 
            this.grbCalHum3.Controls.Add(this.label43);
            this.grbCalHum3.Controls.Add(this.label44);
            this.grbCalHum3.Controls.Add(this.label45);
            this.grbCalHum3.Controls.Add(this.label46);
            this.grbCalHum3.Controls.Add(this.cbbNumCalPoint3);
            this.grbCalHum3.Controls.Add(this.panel9);
            this.grbCalHum3.Controls.Add(this.panel10);
            this.grbCalHum3.Controls.Add(this.panel11);
            this.grbCalHum3.Controls.Add(this.panel12);
            this.grbCalHum3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbCalHum3.Location = new System.Drawing.Point(3, 257);
            this.grbCalHum3.Name = "grbCalHum3";
            this.grbCalHum3.Size = new System.Drawing.Size(431, 195);
            this.grbCalHum3.TabIndex = 27;
            this.grbCalHum3.TabStop = false;
            this.grbCalHum3.Text = "Probe 3: Calib Humid";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(180, 46);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(65, 13);
            this.label43.TabIndex = 25;
            this.label43.Text = "Current rH";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(300, 46);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(83, 13);
            this.label44.TabIndex = 24;
            this.label44.Text = "Reference rH";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(59, 46);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(90, 13);
            this.label45.TabIndex = 23;
            this.label45.Text = "Temperature T";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(7, 21);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(121, 13);
            this.label46.TabIndex = 22;
            this.label46.Text = "Number calibration point";
            // 
            // cbbNumCalPoint3
            // 
            this.cbbNumCalPoint3.FormattingEnabled = true;
            this.cbbNumCalPoint3.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4"});
            this.cbbNumCalPoint3.Location = new System.Drawing.Point(134, 18);
            this.cbbNumCalPoint3.Name = "cbbNumCalPoint3";
            this.cbbNumCalPoint3.Size = new System.Drawing.Size(89, 21);
            this.cbbNumCalPoint3.TabIndex = 21;
            this.cbbNumCalPoint3.SelectedIndexChanged += new System.EventHandler(this.cbbNumCalPoint3_SelectedIndexChanged);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.radioButton8);
            this.panel9.Controls.Add(this.label47);
            this.panel9.Controls.Add(this.label48);
            this.panel9.Controls.Add(this.label49);
            this.panel9.Controls.Add(this.txtRefHum4Prob3);
            this.panel9.Controls.Add(this.label50);
            this.panel9.Controls.Add(this.textBox26);
            this.panel9.Controls.Add(this.textBox27);
            this.panel9.Controls.Add(this.label51);
            this.panel9.Location = new System.Drawing.Point(6, 152);
            this.panel9.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(421, 27);
            this.panel9.TabIndex = 16;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(403, 10);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(14, 13);
            this.radioButton8.TabIndex = 12;
            this.radioButton8.TabStop = true;
            this.radioButton8.UseVisualStyleBackColor = true;
            this.radioButton8.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(144, 6);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(18, 13);
            this.label47.TabIndex = 22;
            this.label47.Text = "°C";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(385, 4);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(15, 13);
            this.label48.TabIndex = 15;
            this.label48.Text = "%";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(265, 6);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(15, 13);
            this.label49.TabIndex = 9;
            this.label49.Text = "%";
            // 
            // txtRefHum4Prob3
            // 
            this.txtRefHum4Prob3.Location = new System.Drawing.Point(297, 4);
            this.txtRefHum4Prob3.Name = "txtRefHum4Prob3";
            this.txtRefHum4Prob3.Size = new System.Drawing.Size(82, 20);
            this.txtRefHum4Prob3.TabIndex = 14;
            this.txtRefHum4Prob3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRefHum4Prob3_KeyPress);
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(156, 6);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(0, 13);
            this.label50.TabIndex = 8;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(177, 3);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(82, 20);
            this.textBox26.TabIndex = 7;
            this.textBox26.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(56, 3);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(82, 20);
            this.textBox27.TabIndex = 5;
            this.textBox27.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(3, 10);
            this.label51.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(47, 13);
            this.label51.TabIndex = 4;
            this.label51.Text = "Point 4";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.radioButton7);
            this.panel10.Controls.Add(this.label52);
            this.panel10.Controls.Add(this.label53);
            this.panel10.Controls.Add(this.txtRefHum3Prob3);
            this.panel10.Controls.Add(this.label54);
            this.panel10.Controls.Add(this.textBox29);
            this.panel10.Controls.Add(this.textBox30);
            this.panel10.Controls.Add(this.label55);
            this.panel10.Location = new System.Drawing.Point(6, 122);
            this.panel10.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(421, 27);
            this.panel10.TabIndex = 17;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(403, 11);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(14, 13);
            this.radioButton7.TabIndex = 12;
            this.radioButton7.TabStop = true;
            this.radioButton7.UseVisualStyleBackColor = true;
            this.radioButton7.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(144, 6);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(18, 13);
            this.label52.TabIndex = 15;
            this.label52.Text = "°C";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(385, 3);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(15, 13);
            this.label53.TabIndex = 13;
            this.label53.Text = "%";
            // 
            // txtRefHum3Prob3
            // 
            this.txtRefHum3Prob3.Location = new System.Drawing.Point(297, 3);
            this.txtRefHum3Prob3.Name = "txtRefHum3Prob3";
            this.txtRefHum3Prob3.Size = new System.Drawing.Size(82, 20);
            this.txtRefHum3Prob3.TabIndex = 12;
            this.txtRefHum3Prob3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRefHum3Prob3_KeyPress);
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(265, 6);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(15, 13);
            this.label54.TabIndex = 9;
            this.label54.Text = "%";
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(177, 3);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(82, 20);
            this.textBox29.TabIndex = 7;
            this.textBox29.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(56, 3);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(82, 20);
            this.textBox30.TabIndex = 5;
            this.textBox30.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(3, 10);
            this.label55.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(47, 13);
            this.label55.TabIndex = 4;
            this.label55.Text = "Point 3";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.radioButton6);
            this.panel11.Controls.Add(this.label56);
            this.panel11.Controls.Add(this.label57);
            this.panel11.Controls.Add(this.label58);
            this.panel11.Controls.Add(this.txtRefHum2Prob3);
            this.panel11.Controls.Add(this.textBox32);
            this.panel11.Controls.Add(this.textBox33);
            this.panel11.Controls.Add(this.label59);
            this.panel11.Location = new System.Drawing.Point(6, 92);
            this.panel11.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(421, 27);
            this.panel11.TabIndex = 15;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Checked = true;
            this.radioButton6.Location = new System.Drawing.Point(403, 9);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(14, 13);
            this.radioButton6.TabIndex = 12;
            this.radioButton6.TabStop = true;
            this.radioButton6.UseVisualStyleBackColor = true;
            this.radioButton6.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(144, 6);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(18, 13);
            this.label56.TabIndex = 14;
            this.label56.Text = "°C";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(385, 6);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(15, 13);
            this.label57.TabIndex = 13;
            this.label57.Text = "%";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(265, 6);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(15, 13);
            this.label58.TabIndex = 9;
            this.label58.Text = "%";
            // 
            // txtRefHum2Prob3
            // 
            this.txtRefHum2Prob3.Location = new System.Drawing.Point(297, 6);
            this.txtRefHum2Prob3.Name = "txtRefHum2Prob3";
            this.txtRefHum2Prob3.Size = new System.Drawing.Size(82, 20);
            this.txtRefHum2Prob3.TabIndex = 12;
            this.txtRefHum2Prob3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRefHum2Prob3_KeyPress);
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(177, 3);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(82, 20);
            this.textBox32.TabIndex = 7;
            this.textBox32.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(56, 3);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(82, 20);
            this.textBox33.TabIndex = 5;
            this.textBox33.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(3, 10);
            this.label59.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(47, 13);
            this.label59.TabIndex = 4;
            this.label59.Text = "Point 2";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.radioButton5);
            this.panel12.Controls.Add(this.label60);
            this.panel12.Controls.Add(this.txtRefHum1Prob3);
            this.panel12.Controls.Add(this.label61);
            this.panel12.Controls.Add(this.label62);
            this.panel12.Controls.Add(this.textBox35);
            this.panel12.Controls.Add(this.textBox36);
            this.panel12.Controls.Add(this.label63);
            this.panel12.Location = new System.Drawing.Point(6, 62);
            this.panel12.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(421, 27);
            this.panel12.TabIndex = 12;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(403, 7);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(14, 13);
            this.radioButton5.TabIndex = 12;
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(385, 6);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(15, 13);
            this.label60.TabIndex = 11;
            this.label60.Text = "%";
            // 
            // txtRefHum1Prob3
            // 
            this.txtRefHum1Prob3.Location = new System.Drawing.Point(297, 3);
            this.txtRefHum1Prob3.Name = "txtRefHum1Prob3";
            this.txtRefHum1Prob3.Size = new System.Drawing.Size(82, 20);
            this.txtRefHum1Prob3.TabIndex = 10;
            this.txtRefHum1Prob3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRefHum1Prob3_KeyPress);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(265, 6);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(15, 13);
            this.label61.TabIndex = 9;
            this.label61.Text = "%";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(144, 6);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(18, 13);
            this.label62.TabIndex = 8;
            this.label62.Text = "°C";
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(177, 3);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(82, 20);
            this.textBox35.TabIndex = 7;
            this.textBox35.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(56, 4);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(82, 20);
            this.textBox36.TabIndex = 5;
            this.textBox36.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(3, 10);
            this.label63.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(47, 13);
            this.label63.TabIndex = 4;
            this.label63.Text = "Point 1";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grbCalTemp3
            // 
            this.grbCalTemp3.Controls.Add(this.label87);
            this.grbCalTemp3.Controls.Add(this.label93);
            this.grbCalTemp3.Controls.Add(this.textBox55);
            this.grbCalTemp3.Location = new System.Drawing.Point(3, 257);
            this.grbCalTemp3.Name = "grbCalTemp3";
            this.grbCalTemp3.Size = new System.Drawing.Size(431, 195);
            this.grbCalTemp3.TabIndex = 28;
            this.grbCalTemp3.TabStop = false;
            this.grbCalTemp3.Text = "Probe 3: Calib Temp";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.Location = new System.Drawing.Point(326, 105);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(35, 13);
            this.label87.TabIndex = 35;
            this.label87.Text = "x10°C";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.Location = new System.Drawing.Point(63, 103);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(70, 13);
            this.label93.TabIndex = 31;
            this.label93.Text = "Data offset";
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(184, 98);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(136, 20);
            this.textBox55.TabIndex = 30;
            this.textBox55.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox55.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            this.textBox55.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox51_KeyPress);
            // 
            // grbCalHum4
            // 
            this.grbCalHum4.Controls.Add(this.label64);
            this.grbCalHum4.Controls.Add(this.label65);
            this.grbCalHum4.Controls.Add(this.label66);
            this.grbCalHum4.Controls.Add(this.label67);
            this.grbCalHum4.Controls.Add(this.cbbNumCalPoint4);
            this.grbCalHum4.Controls.Add(this.panel13);
            this.grbCalHum4.Controls.Add(this.panel14);
            this.grbCalHum4.Controls.Add(this.panel15);
            this.grbCalHum4.Controls.Add(this.panel16);
            this.grbCalHum4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbCalHum4.Location = new System.Drawing.Point(455, 257);
            this.grbCalHum4.Name = "grbCalHum4";
            this.grbCalHum4.Size = new System.Drawing.Size(431, 195);
            this.grbCalHum4.TabIndex = 28;
            this.grbCalHum4.TabStop = false;
            this.grbCalHum4.Text = "Probe 4: Calib Humid";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(180, 46);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(68, 13);
            this.label64.TabIndex = 25;
            this.label64.Text = "Current Rh";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(300, 46);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(86, 13);
            this.label65.TabIndex = 24;
            this.label65.Text = "Reference Rh";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(59, 46);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(90, 13);
            this.label66.TabIndex = 23;
            this.label66.Text = "Temperature T";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(7, 21);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(121, 13);
            this.label67.TabIndex = 22;
            this.label67.Text = "Number calibration point";
            // 
            // cbbNumCalPoint4
            // 
            this.cbbNumCalPoint4.FormattingEnabled = true;
            this.cbbNumCalPoint4.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4"});
            this.cbbNumCalPoint4.Location = new System.Drawing.Point(134, 18);
            this.cbbNumCalPoint4.Name = "cbbNumCalPoint4";
            this.cbbNumCalPoint4.Size = new System.Drawing.Size(89, 21);
            this.cbbNumCalPoint4.TabIndex = 21;
            this.cbbNumCalPoint4.SelectedIndexChanged += new System.EventHandler(this.cbbNumCalPoint4_SelectedIndexChanged);
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.radioButton16);
            this.panel13.Controls.Add(this.label68);
            this.panel13.Controls.Add(this.label69);
            this.panel13.Controls.Add(this.label70);
            this.panel13.Controls.Add(this.txtRefHum4Prob4);
            this.panel13.Controls.Add(this.label71);
            this.panel13.Controls.Add(this.textBox38);
            this.panel13.Controls.Add(this.textBox39);
            this.panel13.Controls.Add(this.label72);
            this.panel13.Location = new System.Drawing.Point(6, 152);
            this.panel13.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(423, 27);
            this.panel13.TabIndex = 16;
            // 
            // radioButton16
            // 
            this.radioButton16.AutoSize = true;
            this.radioButton16.Location = new System.Drawing.Point(406, 7);
            this.radioButton16.Name = "radioButton16";
            this.radioButton16.Size = new System.Drawing.Size(14, 13);
            this.radioButton16.TabIndex = 13;
            this.radioButton16.UseVisualStyleBackColor = true;
            this.radioButton16.CheckedChanged += new System.EventHandler(this.radioButton13_CheckedChanged);
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(144, 6);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(18, 13);
            this.label68.TabIndex = 22;
            this.label68.Text = "°C";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(385, 4);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(15, 13);
            this.label69.TabIndex = 15;
            this.label69.Text = "%";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(265, 6);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(15, 13);
            this.label70.TabIndex = 9;
            this.label70.Text = "%";
            // 
            // txtRefHum4Prob4
            // 
            this.txtRefHum4Prob4.Location = new System.Drawing.Point(297, 4);
            this.txtRefHum4Prob4.Name = "txtRefHum4Prob4";
            this.txtRefHum4Prob4.Size = new System.Drawing.Size(82, 20);
            this.txtRefHum4Prob4.TabIndex = 14;
            this.txtRefHum4Prob4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRefHum4Prob4_KeyPress);
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(156, 6);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(0, 13);
            this.label71.TabIndex = 8;
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(177, 3);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(82, 20);
            this.textBox38.TabIndex = 7;
            this.textBox38.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(56, 3);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(82, 20);
            this.textBox39.TabIndex = 5;
            this.textBox39.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(3, 10);
            this.label72.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(47, 13);
            this.label72.TabIndex = 4;
            this.label72.Text = "Point 4";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.radioButton15);
            this.panel14.Controls.Add(this.label73);
            this.panel14.Controls.Add(this.label74);
            this.panel14.Controls.Add(this.txtRefHum3Prob4);
            this.panel14.Controls.Add(this.label75);
            this.panel14.Controls.Add(this.textBox41);
            this.panel14.Controls.Add(this.textBox42);
            this.panel14.Controls.Add(this.label76);
            this.panel14.Location = new System.Drawing.Point(6, 122);
            this.panel14.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(423, 27);
            this.panel14.TabIndex = 17;
            // 
            // radioButton15
            // 
            this.radioButton15.AutoSize = true;
            this.radioButton15.Location = new System.Drawing.Point(405, 6);
            this.radioButton15.Name = "radioButton15";
            this.radioButton15.Size = new System.Drawing.Size(14, 13);
            this.radioButton15.TabIndex = 13;
            this.radioButton15.UseVisualStyleBackColor = true;
            this.radioButton15.CheckedChanged += new System.EventHandler(this.radioButton13_CheckedChanged);
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.Location = new System.Drawing.Point(144, 6);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(18, 13);
            this.label73.TabIndex = 15;
            this.label73.Text = "°C";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.Location = new System.Drawing.Point(385, 3);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(15, 13);
            this.label74.TabIndex = 13;
            this.label74.Text = "%";
            // 
            // txtRefHum3Prob4
            // 
            this.txtRefHum3Prob4.Location = new System.Drawing.Point(297, 3);
            this.txtRefHum3Prob4.Name = "txtRefHum3Prob4";
            this.txtRefHum3Prob4.Size = new System.Drawing.Size(82, 20);
            this.txtRefHum3Prob4.TabIndex = 12;
            this.txtRefHum3Prob4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRefHum3Prob4_KeyPress);
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.Location = new System.Drawing.Point(265, 6);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(15, 13);
            this.label75.TabIndex = 9;
            this.label75.Text = "%";
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(177, 3);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(82, 20);
            this.textBox41.TabIndex = 7;
            this.textBox41.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(56, 3);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(82, 20);
            this.textBox42.TabIndex = 5;
            this.textBox42.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(3, 10);
            this.label76.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(47, 13);
            this.label76.TabIndex = 4;
            this.label76.Text = "Point 3";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.radioButton14);
            this.panel15.Controls.Add(this.label77);
            this.panel15.Controls.Add(this.label78);
            this.panel15.Controls.Add(this.label79);
            this.panel15.Controls.Add(this.txtRefHum2Prob4);
            this.panel15.Controls.Add(this.textBox44);
            this.panel15.Controls.Add(this.textBox45);
            this.panel15.Controls.Add(this.label80);
            this.panel15.Location = new System.Drawing.Point(6, 92);
            this.panel15.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(423, 27);
            this.panel15.TabIndex = 15;
            // 
            // radioButton14
            // 
            this.radioButton14.AutoSize = true;
            this.radioButton14.Checked = true;
            this.radioButton14.Location = new System.Drawing.Point(405, 6);
            this.radioButton14.Name = "radioButton14";
            this.radioButton14.Size = new System.Drawing.Size(14, 13);
            this.radioButton14.TabIndex = 13;
            this.radioButton14.TabStop = true;
            this.radioButton14.UseVisualStyleBackColor = true;
            this.radioButton14.CheckedChanged += new System.EventHandler(this.radioButton13_CheckedChanged);
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.Location = new System.Drawing.Point(144, 6);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(18, 13);
            this.label77.TabIndex = 14;
            this.label77.Text = "°C";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.Location = new System.Drawing.Point(385, 6);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(15, 13);
            this.label78.TabIndex = 13;
            this.label78.Text = "%";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.Location = new System.Drawing.Point(265, 6);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(15, 13);
            this.label79.TabIndex = 9;
            this.label79.Text = "%";
            // 
            // txtRefHum2Prob4
            // 
            this.txtRefHum2Prob4.Location = new System.Drawing.Point(297, 6);
            this.txtRefHum2Prob4.Name = "txtRefHum2Prob4";
            this.txtRefHum2Prob4.Size = new System.Drawing.Size(82, 20);
            this.txtRefHum2Prob4.TabIndex = 12;
            this.txtRefHum2Prob4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRefHum2Prob4_KeyPress);
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(177, 3);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(82, 20);
            this.textBox44.TabIndex = 7;
            this.textBox44.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(56, 3);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(82, 20);
            this.textBox45.TabIndex = 5;
            this.textBox45.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.Location = new System.Drawing.Point(3, 10);
            this.label80.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(47, 13);
            this.label80.TabIndex = 4;
            this.label80.Text = "Point 2";
            this.label80.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.radioButton13);
            this.panel16.Controls.Add(this.label81);
            this.panel16.Controls.Add(this.txtRefHum1Prob4);
            this.panel16.Controls.Add(this.label82);
            this.panel16.Controls.Add(this.label83);
            this.panel16.Controls.Add(this.textBox47);
            this.panel16.Controls.Add(this.textBox48);
            this.panel16.Controls.Add(this.label84);
            this.panel16.Location = new System.Drawing.Point(6, 62);
            this.panel16.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(423, 27);
            this.panel16.TabIndex = 12;
            // 
            // radioButton13
            // 
            this.radioButton13.AutoSize = true;
            this.radioButton13.Location = new System.Drawing.Point(403, 7);
            this.radioButton13.Name = "radioButton13";
            this.radioButton13.Size = new System.Drawing.Size(14, 13);
            this.radioButton13.TabIndex = 13;
            this.radioButton13.UseVisualStyleBackColor = true;
            this.radioButton13.CheckedChanged += new System.EventHandler(this.radioButton13_CheckedChanged);
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.Location = new System.Drawing.Point(385, 6);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(15, 13);
            this.label81.TabIndex = 11;
            this.label81.Text = "%";
            // 
            // txtRefHum1Prob4
            // 
            this.txtRefHum1Prob4.Location = new System.Drawing.Point(297, 3);
            this.txtRefHum1Prob4.Name = "txtRefHum1Prob4";
            this.txtRefHum1Prob4.Size = new System.Drawing.Size(82, 20);
            this.txtRefHum1Prob4.TabIndex = 10;
            this.txtRefHum1Prob4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRefHum1Prob4_KeyPress);
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.Location = new System.Drawing.Point(265, 6);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(15, 13);
            this.label82.TabIndex = 9;
            this.label82.Text = "%";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.Location = new System.Drawing.Point(144, 6);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(18, 13);
            this.label83.TabIndex = 8;
            this.label83.Text = "°C";
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(177, 3);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(82, 20);
            this.textBox47.TabIndex = 7;
            this.textBox47.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(56, 4);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(82, 20);
            this.textBox48.TabIndex = 5;
            this.textBox48.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.Location = new System.Drawing.Point(3, 10);
            this.label84.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(47, 13);
            this.label84.TabIndex = 4;
            this.label84.Text = "Point 1";
            this.label84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grbCalTemp4
            // 
            this.grbCalTemp4.Controls.Add(this.label85);
            this.grbCalTemp4.Controls.Add(this.label97);
            this.grbCalTemp4.Controls.Add(this.textBox58);
            this.grbCalTemp4.Location = new System.Drawing.Point(455, 257);
            this.grbCalTemp4.Name = "grbCalTemp4";
            this.grbCalTemp4.Size = new System.Drawing.Size(431, 195);
            this.grbCalTemp4.TabIndex = 29;
            this.grbCalTemp4.TabStop = false;
            this.grbCalTemp4.Text = "Probe 4: Calib Temp";
            this.grbCalTemp4.Enter += new System.EventHandler(this.grbCalTemp4_Enter);
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.Location = new System.Drawing.Point(324, 103);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(35, 13);
            this.label85.TabIndex = 35;
            this.label85.Text = "x10°C";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label97.Location = new System.Drawing.Point(61, 103);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(70, 13);
            this.label97.TabIndex = 31;
            this.label97.Text = "Data offset";
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(182, 98);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(136, 20);
            this.textBox58.TabIndex = 30;
            this.textBox58.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox58.TextChanged += new System.EventHandler(this.textBox51_TextChanged);
            this.textBox58.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox51_KeyPress);
            // 
            // btnReadProb3
            // 
            this.btnReadProb3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReadProb3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReadProb3.Location = new System.Drawing.Point(151, 457);
            this.btnReadProb3.Name = "btnReadProb3";
            this.btnReadProb3.Size = new System.Drawing.Size(68, 38);
            this.btnReadProb3.TabIndex = 29;
            this.btnReadProb3.Text = "Read";
            this.btnReadProb3.UseVisualStyleBackColor = true;
            this.btnReadProb3.Click += new System.EventHandler(this.btnReadProb3_Click);
            // 
            // btnCalProb2
            // 
            this.btnCalProb2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalProb2.Location = new System.Drawing.Point(680, 202);
            this.btnCalProb2.Name = "btnCalProb2";
            this.btnCalProb2.Size = new System.Drawing.Size(68, 38);
            this.btnCalProb2.TabIndex = 30;
            this.btnCalProb2.Text = "Calibrate";
            this.btnCalProb2.UseVisualStyleBackColor = true;
            this.btnCalProb2.Click += new System.EventHandler(this.btnCalProb2_Click);
            // 
            // btnCalProb3
            // 
            this.btnCalProb3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalProb3.Location = new System.Drawing.Point(234, 457);
            this.btnCalProb3.Name = "btnCalProb3";
            this.btnCalProb3.Size = new System.Drawing.Size(68, 38);
            this.btnCalProb3.TabIndex = 31;
            this.btnCalProb3.Text = "Calibrate";
            this.btnCalProb3.UseVisualStyleBackColor = true;
            this.btnCalProb3.Click += new System.EventHandler(this.btnCalProb3_Click);
            // 
            // btnCalProb4
            // 
            this.btnCalProb4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalProb4.Location = new System.Drawing.Point(680, 458);
            this.btnCalProb4.Name = "btnCalProb4";
            this.btnCalProb4.Size = new System.Drawing.Size(68, 38);
            this.btnCalProb4.TabIndex = 32;
            this.btnCalProb4.Text = "Calibrate";
            this.btnCalProb4.UseVisualStyleBackColor = true;
            this.btnCalProb4.Click += new System.EventHandler(this.btnCalProb4_Click);
            // 
            // btnReadProb1
            // 
            this.btnReadProb1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReadProb1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReadProb1.Location = new System.Drawing.Point(151, 202);
            this.btnReadProb1.Name = "btnReadProb1";
            this.btnReadProb1.Size = new System.Drawing.Size(68, 38);
            this.btnReadProb1.TabIndex = 29;
            this.btnReadProb1.Text = "Read";
            this.btnReadProb1.UseVisualStyleBackColor = true;
            this.btnReadProb1.Click += new System.EventHandler(this.btnReadProb1_Click);
            // 
            // btnReadProb2
            // 
            this.btnReadProb2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReadProb2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReadProb2.Location = new System.Drawing.Point(596, 202);
            this.btnReadProb2.Name = "btnReadProb2";
            this.btnReadProb2.Size = new System.Drawing.Size(68, 38);
            this.btnReadProb2.TabIndex = 29;
            this.btnReadProb2.Text = "Read";
            this.btnReadProb2.UseVisualStyleBackColor = true;
            this.btnReadProb2.Click += new System.EventHandler(this.btnReadProb2_Click);
            // 
            // btnReadProb4
            // 
            this.btnReadProb4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReadProb4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReadProb4.Location = new System.Drawing.Point(596, 458);
            this.btnReadProb4.Name = "btnReadProb4";
            this.btnReadProb4.Size = new System.Drawing.Size(68, 38);
            this.btnReadProb4.TabIndex = 29;
            this.btnReadProb4.Text = "Read";
            this.btnReadProb4.UseVisualStyleBackColor = true;
            this.btnReadProb4.Click += new System.EventHandler(this.btnReadProb4_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(386, 512);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(113, 43);
            this.button1.TabIndex = 33;
            this.button1.Text = "Reload form";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Calibrations
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(905, 564);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnCalProb4);
            this.Controls.Add(this.btnCalProb3);
            this.Controls.Add(this.btnCalProb1);
            this.Controls.Add(this.btnCalProb2);
            this.Controls.Add(this.btnReadProb4);
            this.Controls.Add(this.btnReadProb2);
            this.Controls.Add(this.btnReadProb1);
            this.Controls.Add(this.btnReadProb3);
            this.Controls.Add(this.grbCalHum2);
            this.Controls.Add(this.grbCalHum1);
            this.Controls.Add(this.grbCalHum3);
            this.Controls.Add(this.grbCalHum4);
            this.Controls.Add(this.grbCalTemp4);
            this.Controls.Add(this.grbCalTemp3);
            this.MaximizeBox = false;
            this.Name = "Calibrations";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calibration Sensor with 4S Loggers";
            this.Load += new System.EventHandler(this.Calibrations_Load_1);
            this.grbCalHum1.ResumeLayout(false);
            this.grbCalHum1.PerformLayout();
            this.grbCalTemp1.ResumeLayout(false);
            this.grbCalTemp1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.grbCalHum2.ResumeLayout(false);
            this.grbCalHum2.PerformLayout();
            this.grbCalTemp2.ResumeLayout(false);
            this.grbCalTemp2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.grbCalHum3.ResumeLayout(false);
            this.grbCalHum3.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.grbCalTemp3.ResumeLayout(false);
            this.grbCalTemp3.PerformLayout();
            this.grbCalHum4.ResumeLayout(false);
            this.grbCalHum4.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.grbCalTemp4.ResumeLayout(false);
            this.grbCalTemp4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox grbCalHum1;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ComboBox cbbNumCalPoint1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button btnCalProb1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtRefHum4Prob1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtRefHum3Prob1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtRefHum2Prob1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtRefHum1Prob1;
        private System.Windows.Forms.GroupBox grbCalHum2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cbbNumCalPoint2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtRefHum4Prob2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtRefHum3Prob2;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtRefHum2Prob2;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtRefHum1Prob2;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.GroupBox grbCalHum3;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.ComboBox cbbNumCalPoint3;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox txtRefHum4Prob3;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox txtRefHum3Prob3;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox txtRefHum2Prob3;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox txtRefHum1Prob3;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.GroupBox grbCalHum4;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.ComboBox cbbNumCalPoint4;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox txtRefHum4Prob4;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.TextBox txtRefHum3Prob4;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.TextBox txtRefHum2Prob4;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.TextBox txtRefHum1Prob4;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Button btnReadProb3;
        private System.Windows.Forms.GroupBox grbCalTemp1;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.GroupBox grbCalTemp3;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.GroupBox grbCalTemp4;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.Button btnCalProb2;
        private System.Windows.Forms.Button btnCalProb3;
        private System.Windows.Forms.Button btnCalProb4;
        private System.Windows.Forms.Button btnReadProb1;
        private System.Windows.Forms.Button btnReadProb2;
        private System.Windows.Forms.Button btnReadProb4;
        private System.Windows.Forms.GroupBox grbCalTemp2;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton16;
        private System.Windows.Forms.RadioButton radioButton15;
        private System.Windows.Forms.RadioButton radioButton14;
        private System.Windows.Forms.RadioButton radioButton13;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label87;
    }
}