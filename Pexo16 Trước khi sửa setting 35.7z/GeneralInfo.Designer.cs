﻿namespace Pexo16
{
    partial class GeneralInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param Name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtChannel8 = new System.Windows.Forms.TextBox();
            this.txtValue8 = new System.Windows.Forms.TextBox();
            this.txtValue7 = new System.Windows.Forms.TextBox();
            this.txtValue6 = new System.Windows.Forms.TextBox();
            this.txtValue5 = new System.Windows.Forms.TextBox();
            this.txtChannel7 = new System.Windows.Forms.TextBox();
            this.txtChannel6 = new System.Windows.Forms.TextBox();
            this.txtChannel5 = new System.Windows.Forms.TextBox();
            this.txtChannel4 = new System.Windows.Forms.TextBox();
            this.txtChannel3 = new System.Windows.Forms.TextBox();
            this.txtChannel2 = new System.Windows.Forms.TextBox();
            this.txtLowAlarm8 = new System.Windows.Forms.TextBox();
            this.txtLowAlarm7 = new System.Windows.Forms.TextBox();
            this.txtLowAlarm6 = new System.Windows.Forms.TextBox();
            this.txtLowAlarm5 = new System.Windows.Forms.TextBox();
            this.txtLowAlarm4 = new System.Windows.Forms.TextBox();
            this.txtLowAlarm3 = new System.Windows.Forms.TextBox();
            this.txtLowAlarm2 = new System.Windows.Forms.TextBox();
            this.txtDescription7 = new System.Windows.Forms.TextBox();
            this.txtDescription5 = new System.Windows.Forms.TextBox();
            this.txtDescription1 = new System.Windows.Forms.TextBox();
            this.txtDescription8 = new System.Windows.Forms.TextBox();
            this.txtDescription6 = new System.Windows.Forms.TextBox();
            this.txtDescription2 = new System.Windows.Forms.TextBox();
            this.txtDescription3 = new System.Windows.Forms.TextBox();
            this.txtDescription4 = new System.Windows.Forms.TextBox();
            this.txtLowAlarm1 = new System.Windows.Forms.TextBox();
            this.txtHighAlarm8 = new System.Windows.Forms.TextBox();
            this.txtHighAlarm7 = new System.Windows.Forms.TextBox();
            this.txtHighAlarm6 = new System.Windows.Forms.TextBox();
            this.txtHighAlarm5 = new System.Windows.Forms.TextBox();
            this.txtHighAlarm4 = new System.Windows.Forms.TextBox();
            this.txtHighAlarm3 = new System.Windows.Forms.TextBox();
            this.txtHighAlarm2 = new System.Windows.Forms.TextBox();
            this.txtHighAlarm1 = new System.Windows.Forms.TextBox();
            this.txtUnit8 = new System.Windows.Forms.TextBox();
            this.txtUnit7 = new System.Windows.Forms.TextBox();
            this.txtUnit6 = new System.Windows.Forms.TextBox();
            this.txtUnit5 = new System.Windows.Forms.TextBox();
            this.txtUnit4 = new System.Windows.Forms.TextBox();
            this.txtUnit3 = new System.Windows.Forms.TextBox();
            this.txtUnit2 = new System.Windows.Forms.TextBox();
            this.txtUnit1 = new System.Windows.Forms.TextBox();
            this.txtValue1 = new System.Windows.Forms.TextBox();
            this.txtValue2 = new System.Windows.Forms.TextBox();
            this.txtValue3 = new System.Windows.Forms.TextBox();
            this.txtValue4 = new System.Windows.Forms.TextBox();
            this.txtChannel1 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtSerialNum = new System.Windows.Forms.TextBox();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.txtMeasurenment = new System.Windows.Forms.TextBox();
            this.txtLocation = new System.Windows.Forms.TextBox();
            this.txtComputerTime = new System.Windows.Forms.TextBox();
            this.txtDelay = new System.Windows.Forms.TextBox();
            this.txtTimeSetting = new System.Windows.Forms.TextBox();
            this.txtDuration = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtHostPort = new System.Windows.Forms.TextBox();
            this.btnRead = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtChannel8);
            this.groupBox1.Controls.Add(this.txtValue8);
            this.groupBox1.Controls.Add(this.txtValue7);
            this.groupBox1.Controls.Add(this.txtValue6);
            this.groupBox1.Controls.Add(this.txtValue5);
            this.groupBox1.Controls.Add(this.txtChannel7);
            this.groupBox1.Controls.Add(this.txtChannel6);
            this.groupBox1.Controls.Add(this.txtChannel5);
            this.groupBox1.Controls.Add(this.txtChannel4);
            this.groupBox1.Controls.Add(this.txtChannel3);
            this.groupBox1.Controls.Add(this.txtChannel2);
            this.groupBox1.Controls.Add(this.txtLowAlarm8);
            this.groupBox1.Controls.Add(this.txtLowAlarm7);
            this.groupBox1.Controls.Add(this.txtLowAlarm6);
            this.groupBox1.Controls.Add(this.txtLowAlarm5);
            this.groupBox1.Controls.Add(this.txtLowAlarm4);
            this.groupBox1.Controls.Add(this.txtLowAlarm3);
            this.groupBox1.Controls.Add(this.txtLowAlarm2);
            this.groupBox1.Controls.Add(this.txtDescription7);
            this.groupBox1.Controls.Add(this.txtDescription5);
            this.groupBox1.Controls.Add(this.txtDescription1);
            this.groupBox1.Controls.Add(this.txtDescription8);
            this.groupBox1.Controls.Add(this.txtDescription6);
            this.groupBox1.Controls.Add(this.txtDescription2);
            this.groupBox1.Controls.Add(this.txtDescription3);
            this.groupBox1.Controls.Add(this.txtDescription4);
            this.groupBox1.Controls.Add(this.txtLowAlarm1);
            this.groupBox1.Controls.Add(this.txtHighAlarm8);
            this.groupBox1.Controls.Add(this.txtHighAlarm7);
            this.groupBox1.Controls.Add(this.txtHighAlarm6);
            this.groupBox1.Controls.Add(this.txtHighAlarm5);
            this.groupBox1.Controls.Add(this.txtHighAlarm4);
            this.groupBox1.Controls.Add(this.txtHighAlarm3);
            this.groupBox1.Controls.Add(this.txtHighAlarm2);
            this.groupBox1.Controls.Add(this.txtHighAlarm1);
            this.groupBox1.Controls.Add(this.txtUnit8);
            this.groupBox1.Controls.Add(this.txtUnit7);
            this.groupBox1.Controls.Add(this.txtUnit6);
            this.groupBox1.Controls.Add(this.txtUnit5);
            this.groupBox1.Controls.Add(this.txtUnit4);
            this.groupBox1.Controls.Add(this.txtUnit3);
            this.groupBox1.Controls.Add(this.txtUnit2);
            this.groupBox1.Controls.Add(this.txtUnit1);
            this.groupBox1.Controls.Add(this.txtValue1);
            this.groupBox1.Controls.Add(this.txtValue2);
            this.groupBox1.Controls.Add(this.txtValue3);
            this.groupBox1.Controls.Add(this.txtValue4);
            this.groupBox1.Controls.Add(this.txtChannel1);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txtSerialNum);
            this.groupBox1.Controls.Add(this.txtDescription);
            this.groupBox1.Controls.Add(this.txtMeasurenment);
            this.groupBox1.Controls.Add(this.txtLocation);
            this.groupBox1.Controls.Add(this.txtComputerTime);
            this.groupBox1.Controls.Add(this.txtDelay);
            this.groupBox1.Controls.Add(this.txtTimeSetting);
            this.groupBox1.Controls.Add(this.txtDuration);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(992, 462);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // txtChannel8
            // 
            this.txtChannel8.Location = new System.Drawing.Point(20, 431);
            this.txtChannel8.Name = "txtChannel8";
            this.txtChannel8.Size = new System.Drawing.Size(100, 20);
            this.txtChannel8.TabIndex = 4;
            this.txtChannel8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtValue8
            // 
            this.txtValue8.Location = new System.Drawing.Point(163, 432);
            this.txtValue8.Name = "txtValue8";
            this.txtValue8.Size = new System.Drawing.Size(100, 20);
            this.txtValue8.TabIndex = 4;
            this.txtValue8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtValue7
            // 
            this.txtValue7.Location = new System.Drawing.Point(163, 403);
            this.txtValue7.Name = "txtValue7";
            this.txtValue7.Size = new System.Drawing.Size(100, 20);
            this.txtValue7.TabIndex = 4;
            this.txtValue7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtValue6
            // 
            this.txtValue6.Location = new System.Drawing.Point(163, 374);
            this.txtValue6.Name = "txtValue6";
            this.txtValue6.Size = new System.Drawing.Size(100, 20);
            this.txtValue6.TabIndex = 4;
            this.txtValue6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtValue5
            // 
            this.txtValue5.Location = new System.Drawing.Point(163, 345);
            this.txtValue5.Name = "txtValue5";
            this.txtValue5.Size = new System.Drawing.Size(100, 20);
            this.txtValue5.TabIndex = 4;
            this.txtValue5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtChannel7
            // 
            this.txtChannel7.Location = new System.Drawing.Point(20, 402);
            this.txtChannel7.Name = "txtChannel7";
            this.txtChannel7.Size = new System.Drawing.Size(100, 20);
            this.txtChannel7.TabIndex = 4;
            this.txtChannel7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtChannel6
            // 
            this.txtChannel6.Location = new System.Drawing.Point(20, 373);
            this.txtChannel6.Name = "txtChannel6";
            this.txtChannel6.Size = new System.Drawing.Size(100, 20);
            this.txtChannel6.TabIndex = 4;
            this.txtChannel6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtChannel5
            // 
            this.txtChannel5.Location = new System.Drawing.Point(20, 342);
            this.txtChannel5.Name = "txtChannel5";
            this.txtChannel5.Size = new System.Drawing.Size(100, 20);
            this.txtChannel5.TabIndex = 4;
            this.txtChannel5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtChannel4
            // 
            this.txtChannel4.Location = new System.Drawing.Point(20, 314);
            this.txtChannel4.Name = "txtChannel4";
            this.txtChannel4.Size = new System.Drawing.Size(100, 20);
            this.txtChannel4.TabIndex = 4;
            this.txtChannel4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtChannel3
            // 
            this.txtChannel3.Location = new System.Drawing.Point(20, 284);
            this.txtChannel3.Name = "txtChannel3";
            this.txtChannel3.Size = new System.Drawing.Size(100, 20);
            this.txtChannel3.TabIndex = 4;
            this.txtChannel3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtChannel2
            // 
            this.txtChannel2.Location = new System.Drawing.Point(20, 255);
            this.txtChannel2.Name = "txtChannel2";
            this.txtChannel2.Size = new System.Drawing.Size(100, 20);
            this.txtChannel2.TabIndex = 4;
            this.txtChannel2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtLowAlarm8
            // 
            this.txtLowAlarm8.Location = new System.Drawing.Point(577, 431);
            this.txtLowAlarm8.Name = "txtLowAlarm8";
            this.txtLowAlarm8.Size = new System.Drawing.Size(100, 20);
            this.txtLowAlarm8.TabIndex = 4;
            this.txtLowAlarm8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtLowAlarm7
            // 
            this.txtLowAlarm7.Location = new System.Drawing.Point(577, 402);
            this.txtLowAlarm7.Name = "txtLowAlarm7";
            this.txtLowAlarm7.Size = new System.Drawing.Size(100, 20);
            this.txtLowAlarm7.TabIndex = 4;
            this.txtLowAlarm7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtLowAlarm6
            // 
            this.txtLowAlarm6.Location = new System.Drawing.Point(577, 373);
            this.txtLowAlarm6.Name = "txtLowAlarm6";
            this.txtLowAlarm6.Size = new System.Drawing.Size(100, 20);
            this.txtLowAlarm6.TabIndex = 4;
            this.txtLowAlarm6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtLowAlarm5
            // 
            this.txtLowAlarm5.Location = new System.Drawing.Point(577, 342);
            this.txtLowAlarm5.Name = "txtLowAlarm5";
            this.txtLowAlarm5.Size = new System.Drawing.Size(100, 20);
            this.txtLowAlarm5.TabIndex = 4;
            this.txtLowAlarm5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtLowAlarm4
            // 
            this.txtLowAlarm4.Location = new System.Drawing.Point(577, 313);
            this.txtLowAlarm4.Name = "txtLowAlarm4";
            this.txtLowAlarm4.Size = new System.Drawing.Size(100, 20);
            this.txtLowAlarm4.TabIndex = 4;
            this.txtLowAlarm4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtLowAlarm3
            // 
            this.txtLowAlarm3.Location = new System.Drawing.Point(577, 281);
            this.txtLowAlarm3.Name = "txtLowAlarm3";
            this.txtLowAlarm3.Size = new System.Drawing.Size(100, 20);
            this.txtLowAlarm3.TabIndex = 4;
            this.txtLowAlarm3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtLowAlarm2
            // 
            this.txtLowAlarm2.Location = new System.Drawing.Point(577, 255);
            this.txtLowAlarm2.Name = "txtLowAlarm2";
            this.txtLowAlarm2.Size = new System.Drawing.Size(100, 20);
            this.txtLowAlarm2.TabIndex = 4;
            this.txtLowAlarm2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDescription7
            // 
            this.txtDescription7.Location = new System.Drawing.Point(725, 402);
            this.txtDescription7.Name = "txtDescription7";
            this.txtDescription7.Size = new System.Drawing.Size(236, 20);
            this.txtDescription7.TabIndex = 4;
            this.txtDescription7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDescription5
            // 
            this.txtDescription5.Location = new System.Drawing.Point(725, 342);
            this.txtDescription5.Name = "txtDescription5";
            this.txtDescription5.Size = new System.Drawing.Size(236, 20);
            this.txtDescription5.TabIndex = 4;
            this.txtDescription5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDescription1
            // 
            this.txtDescription1.Location = new System.Drawing.Point(725, 226);
            this.txtDescription1.Name = "txtDescription1";
            this.txtDescription1.Size = new System.Drawing.Size(236, 20);
            this.txtDescription1.TabIndex = 4;
            this.txtDescription1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDescription8
            // 
            this.txtDescription8.Location = new System.Drawing.Point(725, 428);
            this.txtDescription8.Name = "txtDescription8";
            this.txtDescription8.Size = new System.Drawing.Size(236, 20);
            this.txtDescription8.TabIndex = 4;
            this.txtDescription8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDescription6
            // 
            this.txtDescription6.Location = new System.Drawing.Point(725, 373);
            this.txtDescription6.Name = "txtDescription6";
            this.txtDescription6.Size = new System.Drawing.Size(236, 20);
            this.txtDescription6.TabIndex = 4;
            this.txtDescription6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDescription2
            // 
            this.txtDescription2.Location = new System.Drawing.Point(725, 255);
            this.txtDescription2.Name = "txtDescription2";
            this.txtDescription2.Size = new System.Drawing.Size(236, 20);
            this.txtDescription2.TabIndex = 4;
            this.txtDescription2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDescription3
            // 
            this.txtDescription3.Location = new System.Drawing.Point(725, 281);
            this.txtDescription3.Name = "txtDescription3";
            this.txtDescription3.Size = new System.Drawing.Size(236, 20);
            this.txtDescription3.TabIndex = 4;
            this.txtDescription3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDescription4
            // 
            this.txtDescription4.Location = new System.Drawing.Point(725, 314);
            this.txtDescription4.Name = "txtDescription4";
            this.txtDescription4.Size = new System.Drawing.Size(236, 20);
            this.txtDescription4.TabIndex = 4;
            this.txtDescription4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtLowAlarm1
            // 
            this.txtLowAlarm1.Location = new System.Drawing.Point(577, 226);
            this.txtLowAlarm1.Name = "txtLowAlarm1";
            this.txtLowAlarm1.Size = new System.Drawing.Size(100, 20);
            this.txtLowAlarm1.TabIndex = 4;
            this.txtLowAlarm1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtHighAlarm8
            // 
            this.txtHighAlarm8.Location = new System.Drawing.Point(441, 428);
            this.txtHighAlarm8.Name = "txtHighAlarm8";
            this.txtHighAlarm8.Size = new System.Drawing.Size(100, 20);
            this.txtHighAlarm8.TabIndex = 4;
            this.txtHighAlarm8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtHighAlarm7
            // 
            this.txtHighAlarm7.Location = new System.Drawing.Point(441, 402);
            this.txtHighAlarm7.Name = "txtHighAlarm7";
            this.txtHighAlarm7.Size = new System.Drawing.Size(100, 20);
            this.txtHighAlarm7.TabIndex = 4;
            this.txtHighAlarm7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtHighAlarm6
            // 
            this.txtHighAlarm6.Location = new System.Drawing.Point(441, 373);
            this.txtHighAlarm6.Name = "txtHighAlarm6";
            this.txtHighAlarm6.Size = new System.Drawing.Size(100, 20);
            this.txtHighAlarm6.TabIndex = 4;
            this.txtHighAlarm6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtHighAlarm5
            // 
            this.txtHighAlarm5.Location = new System.Drawing.Point(441, 342);
            this.txtHighAlarm5.Name = "txtHighAlarm5";
            this.txtHighAlarm5.Size = new System.Drawing.Size(100, 20);
            this.txtHighAlarm5.TabIndex = 4;
            this.txtHighAlarm5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtHighAlarm4
            // 
            this.txtHighAlarm4.Location = new System.Drawing.Point(441, 314);
            this.txtHighAlarm4.Name = "txtHighAlarm4";
            this.txtHighAlarm4.Size = new System.Drawing.Size(100, 20);
            this.txtHighAlarm4.TabIndex = 4;
            this.txtHighAlarm4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtHighAlarm3
            // 
            this.txtHighAlarm3.Location = new System.Drawing.Point(441, 281);
            this.txtHighAlarm3.Name = "txtHighAlarm3";
            this.txtHighAlarm3.Size = new System.Drawing.Size(100, 20);
            this.txtHighAlarm3.TabIndex = 4;
            this.txtHighAlarm3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtHighAlarm2
            // 
            this.txtHighAlarm2.Location = new System.Drawing.Point(441, 255);
            this.txtHighAlarm2.Name = "txtHighAlarm2";
            this.txtHighAlarm2.Size = new System.Drawing.Size(100, 20);
            this.txtHighAlarm2.TabIndex = 4;
            this.txtHighAlarm2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtHighAlarm1
            // 
            this.txtHighAlarm1.Location = new System.Drawing.Point(441, 226);
            this.txtHighAlarm1.Name = "txtHighAlarm1";
            this.txtHighAlarm1.Size = new System.Drawing.Size(100, 20);
            this.txtHighAlarm1.TabIndex = 4;
            this.txtHighAlarm1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtUnit8
            // 
            this.txtUnit8.Location = new System.Drawing.Point(303, 428);
            this.txtUnit8.Name = "txtUnit8";
            this.txtUnit8.Size = new System.Drawing.Size(100, 20);
            this.txtUnit8.TabIndex = 4;
            this.txtUnit8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtUnit7
            // 
            this.txtUnit7.Location = new System.Drawing.Point(303, 402);
            this.txtUnit7.Name = "txtUnit7";
            this.txtUnit7.Size = new System.Drawing.Size(100, 20);
            this.txtUnit7.TabIndex = 4;
            this.txtUnit7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtUnit6
            // 
            this.txtUnit6.Location = new System.Drawing.Point(303, 373);
            this.txtUnit6.Name = "txtUnit6";
            this.txtUnit6.Size = new System.Drawing.Size(100, 20);
            this.txtUnit6.TabIndex = 4;
            this.txtUnit6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtUnit5
            // 
            this.txtUnit5.Location = new System.Drawing.Point(303, 342);
            this.txtUnit5.Name = "txtUnit5";
            this.txtUnit5.Size = new System.Drawing.Size(100, 20);
            this.txtUnit5.TabIndex = 4;
            this.txtUnit5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtUnit4
            // 
            this.txtUnit4.Location = new System.Drawing.Point(303, 313);
            this.txtUnit4.Name = "txtUnit4";
            this.txtUnit4.Size = new System.Drawing.Size(100, 20);
            this.txtUnit4.TabIndex = 4;
            this.txtUnit4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtUnit3
            // 
            this.txtUnit3.Location = new System.Drawing.Point(303, 281);
            this.txtUnit3.Name = "txtUnit3";
            this.txtUnit3.Size = new System.Drawing.Size(100, 20);
            this.txtUnit3.TabIndex = 4;
            this.txtUnit3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtUnit2
            // 
            this.txtUnit2.Location = new System.Drawing.Point(303, 255);
            this.txtUnit2.Name = "txtUnit2";
            this.txtUnit2.Size = new System.Drawing.Size(100, 20);
            this.txtUnit2.TabIndex = 4;
            this.txtUnit2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtUnit1
            // 
            this.txtUnit1.Location = new System.Drawing.Point(303, 226);
            this.txtUnit1.Name = "txtUnit1";
            this.txtUnit1.Size = new System.Drawing.Size(100, 20);
            this.txtUnit1.TabIndex = 4;
            this.txtUnit1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtValue1
            // 
            this.txtValue1.Location = new System.Drawing.Point(163, 226);
            this.txtValue1.Name = "txtValue1";
            this.txtValue1.Size = new System.Drawing.Size(100, 20);
            this.txtValue1.TabIndex = 4;
            this.txtValue1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtValue2
            // 
            this.txtValue2.Location = new System.Drawing.Point(163, 256);
            this.txtValue2.Name = "txtValue2";
            this.txtValue2.Size = new System.Drawing.Size(100, 20);
            this.txtValue2.TabIndex = 4;
            this.txtValue2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtValue3
            // 
            this.txtValue3.Location = new System.Drawing.Point(163, 285);
            this.txtValue3.Name = "txtValue3";
            this.txtValue3.Size = new System.Drawing.Size(100, 20);
            this.txtValue3.TabIndex = 4;
            this.txtValue3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtValue4
            // 
            this.txtValue4.Location = new System.Drawing.Point(163, 314);
            this.txtValue4.Name = "txtValue4";
            this.txtValue4.Size = new System.Drawing.Size(100, 20);
            this.txtValue4.TabIndex = 4;
            this.txtValue4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtChannel1
            // 
            this.txtChannel1.Location = new System.Drawing.Point(20, 226);
            this.txtChannel1.Name = "txtChannel1";
            this.txtChannel1.Size = new System.Drawing.Size(100, 20);
            this.txtChannel1.TabIndex = 4;
            this.txtChannel1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(789, 194);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(137, 15);
            this.label14.TabIndex = 3;
            this.label14.Text = "Channel Description";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(574, 194);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(106, 15);
            this.label13.TabIndex = 3;
            this.label13.Text = "Low alarm limit";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(438, 194);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(110, 15);
            this.label12.TabIndex = 3;
            this.label12.Text = "High alarm limit";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(331, 194);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(33, 15);
            this.label11.TabIndex = 3;
            this.label11.Text = "Unit";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(160, 194);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 15);
            this.label10.TabIndex = 3;
            this.label10.Text = "Current Value";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(41, 194);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 15);
            this.label9.TabIndex = 3;
            this.label9.Text = "Channel";
            // 
            // txtSerialNum
            // 
            this.txtSerialNum.Location = new System.Drawing.Point(20, 35);
            this.txtSerialNum.Name = "txtSerialNum";
            this.txtSerialNum.Size = new System.Drawing.Size(270, 20);
            this.txtSerialNum.TabIndex = 2;
            this.txtSerialNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(693, 35);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(268, 20);
            this.txtDescription.TabIndex = 1;
            this.txtDescription.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtMeasurenment
            // 
            this.txtMeasurenment.Location = new System.Drawing.Point(693, 88);
            this.txtMeasurenment.Name = "txtMeasurenment";
            this.txtMeasurenment.Size = new System.Drawing.Size(268, 20);
            this.txtMeasurenment.TabIndex = 1;
            this.txtMeasurenment.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtLocation
            // 
            this.txtLocation.Location = new System.Drawing.Point(344, 35);
            this.txtLocation.Name = "txtLocation";
            this.txtLocation.Size = new System.Drawing.Size(282, 20);
            this.txtLocation.TabIndex = 1;
            this.txtLocation.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtComputerTime
            // 
            this.txtComputerTime.Location = new System.Drawing.Point(344, 141);
            this.txtComputerTime.Name = "txtComputerTime";
            this.txtComputerTime.Size = new System.Drawing.Size(282, 20);
            this.txtComputerTime.TabIndex = 1;
            this.txtComputerTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDelay
            // 
            this.txtDelay.Location = new System.Drawing.Point(344, 88);
            this.txtDelay.Name = "txtDelay";
            this.txtDelay.Size = new System.Drawing.Size(282, 20);
            this.txtDelay.TabIndex = 1;
            this.txtDelay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtTimeSetting
            // 
            this.txtTimeSetting.Location = new System.Drawing.Point(20, 141);
            this.txtTimeSetting.Name = "txtTimeSetting";
            this.txtTimeSetting.Size = new System.Drawing.Size(270, 20);
            this.txtTimeSetting.TabIndex = 1;
            this.txtTimeSetting.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDuration
            // 
            this.txtDuration.Location = new System.Drawing.Point(20, 88);
            this.txtDuration.Name = "txtDuration";
            this.txtDuration.Size = new System.Drawing.Size(270, 20);
            this.txtDuration.TabIndex = 1;
            this.txtDuration.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(690, 69);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(146, 15);
            this.label8.TabIndex = 0;
            this.label8.Text = "Measurement Interval";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(690, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 15);
            this.label7.TabIndex = 0;
            this.label7.Text = "Description";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(341, 122);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 15);
            this.label6.TabIndex = 0;
            this.label6.Text = "Computer Time";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(341, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 15);
            this.label5.TabIndex = 0;
            this.label5.Text = "Start Delay";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(341, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 15);
            this.label4.TabIndex = 0;
            this.label4.Text = "Location";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(17, 122);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(135, 15);
            this.label3.TabIndex = 0;
            this.label3.Text = "Logger setting Time";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "Duration ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Serial number";
            // 
            // txtHostPort
            // 
            this.txtHostPort.Location = new System.Drawing.Point(32, 490);
            this.txtHostPort.Name = "txtHostPort";
            this.txtHostPort.Size = new System.Drawing.Size(306, 20);
            this.txtHostPort.TabIndex = 1;
            this.txtHostPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnRead
            // 
            this.btnRead.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRead.Location = new System.Drawing.Point(115, 526);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(151, 38);
            this.btnRead.TabIndex = 2;
            this.btnRead.Text = "Read";
            this.btnRead.UseVisualStyleBackColor = true;
            this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.Location = new System.Drawing.Point(678, 507);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(121, 43);
            this.btnPrint.TabIndex = 4;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(832, 507);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(112, 40);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // GeneralInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1020, 576);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.btnRead);
            this.Controls.Add(this.txtHostPort);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "GeneralInfo";
            this.Text = "General Infomation";
            this.Load += new System.EventHandler(this.frmGeneralInfo_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.TextBox txtMeasurenment;
        private System.Windows.Forms.TextBox txtLocation;
        private System.Windows.Forms.TextBox txtComputerTime;
        private System.Windows.Forms.TextBox txtDelay;
        private System.Windows.Forms.TextBox txtTimeSetting;
        private System.Windows.Forms.TextBox txtDuration;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtChannel8;
        private System.Windows.Forms.TextBox txtValue8;
        private System.Windows.Forms.TextBox txtValue7;
        private System.Windows.Forms.TextBox txtValue6;
        private System.Windows.Forms.TextBox txtValue5;
        private System.Windows.Forms.TextBox txtChannel7;
        private System.Windows.Forms.TextBox txtChannel6;
        private System.Windows.Forms.TextBox txtChannel5;
        private System.Windows.Forms.TextBox txtChannel4;
        private System.Windows.Forms.TextBox txtChannel3;
        private System.Windows.Forms.TextBox txtChannel2;
        private System.Windows.Forms.TextBox txtLowAlarm8;
        private System.Windows.Forms.TextBox txtLowAlarm7;
        private System.Windows.Forms.TextBox txtLowAlarm6;
        private System.Windows.Forms.TextBox txtLowAlarm5;
        private System.Windows.Forms.TextBox txtLowAlarm4;
        private System.Windows.Forms.TextBox txtLowAlarm3;
        private System.Windows.Forms.TextBox txtLowAlarm2;
        private System.Windows.Forms.TextBox txtDescription7;
        private System.Windows.Forms.TextBox txtDescription5;
        private System.Windows.Forms.TextBox txtDescription1;
        private System.Windows.Forms.TextBox txtDescription8;
        private System.Windows.Forms.TextBox txtDescription6;
        private System.Windows.Forms.TextBox txtDescription2;
        private System.Windows.Forms.TextBox txtDescription3;
        private System.Windows.Forms.TextBox txtDescription4;
        private System.Windows.Forms.TextBox txtLowAlarm1;
        private System.Windows.Forms.TextBox txtHighAlarm8;
        private System.Windows.Forms.TextBox txtHighAlarm7;
        private System.Windows.Forms.TextBox txtHighAlarm6;
        private System.Windows.Forms.TextBox txtHighAlarm5;
        private System.Windows.Forms.TextBox txtHighAlarm4;
        private System.Windows.Forms.TextBox txtHighAlarm3;
        private System.Windows.Forms.TextBox txtHighAlarm2;
        private System.Windows.Forms.TextBox txtHighAlarm1;
        private System.Windows.Forms.TextBox txtUnit8;
        private System.Windows.Forms.TextBox txtUnit7;
        private System.Windows.Forms.TextBox txtUnit6;
        private System.Windows.Forms.TextBox txtUnit5;
        private System.Windows.Forms.TextBox txtUnit4;
        private System.Windows.Forms.TextBox txtUnit3;
        private System.Windows.Forms.TextBox txtUnit2;
        private System.Windows.Forms.TextBox txtUnit1;
        private System.Windows.Forms.TextBox txtValue1;
        private System.Windows.Forms.TextBox txtValue2;
        private System.Windows.Forms.TextBox txtValue3;
        private System.Windows.Forms.TextBox txtValue4;
        private System.Windows.Forms.TextBox txtChannel1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtSerialNum;
        private System.Windows.Forms.TextBox txtHostPort;
        private System.Windows.Forms.Button btnRead;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Timer timer1;
    }
}